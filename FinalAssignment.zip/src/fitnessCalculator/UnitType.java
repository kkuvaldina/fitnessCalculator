package fitnessCalculator;

public enum UnitType {US, METRIC;}